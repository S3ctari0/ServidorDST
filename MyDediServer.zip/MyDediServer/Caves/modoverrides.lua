return {
  ["workshop-356494979"]={ configuration_options={  }, enabled=true },
  ["workshop-632082897"]={ configuration_options={  }, enabled=true },
  ["workshop-666155465"]={
    configuration_options={
      chestB=-1,
      chestG=-1,
      chestR=-1,
      display_hp=-1,
      food_estimation=-1,
      food_order=0,
      food_style=0,
      lang="auto",
      show_food_units=-1,
      show_uses=-1 
    },
    enabled=true 
  } 
}